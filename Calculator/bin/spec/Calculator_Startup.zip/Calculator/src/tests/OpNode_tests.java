package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class OpNode_tests {

    @Test
    void test_createNode() {
        // TODO: Create OpNodes for each of the supported operators (i.e. "+",..)
        // TODO: and verify they reflect back the the correct operator code (i.e. OpCode.ADDITION)
        fail("Test not implemented");
    }
    
    @Test
    void test_evaluate() {
        // TODO: Create a valid sequence of NumNode, OpNode, NumNode, chain them in a linked list
        // TODO: And verify the result of the evaluation of the operator node is as expected.
        fail("Test not implemented");
    }
}

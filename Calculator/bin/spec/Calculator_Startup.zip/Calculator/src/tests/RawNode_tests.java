package tests;

import static org.junit.Assert.fail;

import org.junit.jupiter.api.Test;

class RawNode_tests {

    @Test
    void test_createRawNode() {
        // TODO: Create a new RawNode
        // TODO: and verify the content is as expected
        // TODO: and that its links are null.
        fail("Test not implemented");
    }
    
    @Test
    void test_addNext() {
        // TODO: Create two nodes, n1 and n2, add one next to the other and
        // TODO: verify their links are pointing to their respective nodes.
        // TODO: Create a third node n3, add it after n1 and verify its links
        // TODO: are pointing to n1 and n2 respectively, and that
        // TODO: the n1 and n2 links were adjusted accordingly as well.
        fail("Test not implemented");
    }
    
    @Test
    void test_addTail() {
        // TODO: Create three nodes, n1, n2 and n3, add them into a three nodes list
        // TODO: then create a fourth node n, adding it to the tail of the list pointed by n1.
        // TODO: verify n links are pointing to n3 and null, while n3 next link is now pointing to n.
        fail("Test not implemented");
    }
}

package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class NumNode_tests {

    @Test
    void test_createNode() {
        // TODO: Create a few numerical nodes with various correct numerical values given strings
        // TODO: and verify they reflect their content correctly as a double value.
        // TODO: Try create a numerical node with an invalid string and
        // TODO: verify the result is a null reference.
        fail("Test not implemented");
    }

}
